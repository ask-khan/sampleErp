## SP Theme

Default theme for Smart Paradigm

#### License

MIT